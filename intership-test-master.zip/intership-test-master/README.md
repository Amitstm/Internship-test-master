Firstly navigate to your directory, where this solution.py file is present
Then run the "solution.py" file by using following command:

		python solution.py

The above command will automatically generate two files in the "output" directory

The output directory will contain two file after executing the above mentioned command:
1. filteredCountry.csv &
2. lowestPrice.csv

filteredCountry.csv contains the data as per your instructions given in Problem Statement "1"
and lowestPrice.csv contains the data as per your instructions given in Problem Statement "2"